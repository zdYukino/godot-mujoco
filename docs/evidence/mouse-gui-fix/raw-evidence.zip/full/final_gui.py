from stage_utils import *
frozen['commit']='df049af78999ab60b0e102191bd6842a00021fbd'
for label,script in [('mouse-gui-final','tests/editor_plugin/run_mouse.sh'),('g1-gui-final','tests/freebase/run_gui.sh')]:
 run(label,['bash',script],540,{'OUT':str(out/label),'DISPLAY':':91','PYTHONPATH':'/workspace/shared/gui-packages/python'})
