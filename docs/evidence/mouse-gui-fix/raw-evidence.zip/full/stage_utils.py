import os,sys,pathlib,subprocess,json,time,signal,hashlib,shutil
root=pathlib.Path('/workspace/godot-mujoco');out=pathlib.Path('/workspace/shared/validation/mouse-fix/full');godot=os.environ['GODOT_BIN'];rows=json.loads((out/"commands.json").read_text())
cpus=sorted(os.sched_getaffinity(0))[:2]
def process_table():
 result={}
 for path in pathlib.Path('/proc').glob('[0-9]*'):
  try:
   text=(path/'stat').read_text();fields=text[text.rfind(')')+2:].split();result[int(path.name)]={'ppid':int(fields[1]),'start':fields[19],'state':fields[0],'cmd':(path/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')}
  except (OSError,ValueError):pass
 return result
baseline=process_table();frozen=json.loads((out/"frozen.json").read_text())
def run(label,cmd,limit=600,env=None):
 full=['timeout','--kill-after=5',str(limit),'nice','-n','10','taskset','-c',','.join(map(str,cpus))]+cmd
 own={};start=time.monotonic();e=os.environ.copy();e.update(env or {});e.update(DOTNET_CLI_DO_NOT_USE_MSBUILD_SERVER='1',MSBUILDDISABLENODEREUSE='1',UseSharedCompilation='false')
 print('START',label,flush=True)
 with (out/(label+'-driver.log')).open('w') as log:
  p=subprocess.Popen(full,cwd=root,env=e,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  while p.poll() is None:
   table=process_table();parents={p.pid}|set(own)
   for unused in range(6):
    for pid,v in table.items():
     if v['ppid'] in parents and pid not in baseline:own[pid]=v['start'];parents.add(pid)
   time.sleep(.4)
  rc=p.wait()
 cleaned=[];table=process_table()
 for pid,stamp in own.items():
  if pid in table and table[pid]['start']==stamp and table[pid]['state']!='Z':
   try:os.kill(pid,signal.SIGTERM);cleaned.append(pid)
   except ProcessLookupError:pass
 time.sleep(.3)
 table=process_table();survivors=[pid for pid in cleaned if pid in table and table[pid]['start']==own[pid] and table[pid]['state']!='Z']
 for pid in survivors:
  try:os.kill(pid,signal.SIGKILL)
  except ProcessLookupError:pass
 row={'label':label,'command':full,'env_overrides':env or {},'exit':rc,'seconds':round(time.monotonic()-start,2),'source_commit':frozen['commit'],'terminated_owned_children':cleaned,'killed_after_term':survivors};rows.append(row);(out/'commands.json').write_text(json.dumps(rows,indent=2));print('DONE',label,rc,row['seconds'],flush=True);return rc
