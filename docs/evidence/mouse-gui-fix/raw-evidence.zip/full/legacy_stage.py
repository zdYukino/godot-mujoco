from stage_utils import *
for label,scene in [('legacy-chaos','ChaosPendulumTest.tscn'),('legacy-debug-data','VisualDebugTest.tscn')]:
 run(label,[godot,'--headless','--path',str(out/'g1/godot'),'res://'+scene],120)
