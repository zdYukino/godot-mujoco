import pathlib,json,re
out=pathlib.Path('/workspace/shared/validation/mouse-fix/full');commands=json.loads((out/'commands.json').read_text());report=[]
for row in commands:
 label=row['label'];files=[out/(label+'-driver.log')]
 directory=out/label
 if directory.exists():files += [f for f in directory.glob('*.log') if not (label=='smoke-isolated' and f.name=='negative.log')]
 if label.startswith('g1-gui') and (directory/'gui').exists():files += list((directory/'gui').glob('*.log'))
 diagnostics=[];markers=[]
 for f in files:
  text=f.read_text(errors='replace')
  diagnostics += [{'file':str(f.relative_to(out)),'line':i,'text':line} for i,line in enumerate(text.splitlines(),1) if 'ERROR:' in line or 'leaked' in line]
  for line in text.splitlines():
   if re.search(r'(RESULT|TEST:|PASS|Ran \d+ tests)',line):
    if len(line)<500:markers.append({'file':str(f.relative_to(out)),'text':line})
    elif 'RESULT ' in line:
     try:
      d=json.loads(line.split('RESULT ',1)[1]);markers.append({'file':str(f.relative_to(out)),'summary':{k:v for k,v in d.items() if k not in ['checks','failures'] or not isinstance(v,list)}})
     except ValueError:pass
 result={'label':label,'source_commit':row['source_commit'],'exit':row['exit'],'seconds':row['seconds'],'strict_status':'PASS' if row['exit']==0 and not diagnostics else 'FAIL','diagnostics':diagnostics,'markers':markers}
 if label.startswith('f5-'):
  valid=not row.get('forced_stop') and not row.get('automation_error') and bool(row.get('cycles'))
  for cycle in row.get('cycles',[]):
   valid=valid and not cycle['children_after_f8'] and any('--wid ' in c['command'] for capture in cycle['captures'] for c in capture['children'])
  result['automation_error']=row.get('automation_error','')
  result['embedded_lifecycle_verified']=bool(valid)
  result['visual_status']=row.get('visual_status','not separately established')
  if row.get('visual_status','').startswith('PARTIAL'):result['strict_status']='PARTIAL'
  if not valid:result['strict_status']='FAIL'
 if label.startswith('editor-gui-') and not label.endswith('-import'):
  p=out/label/'results.json'
  if p.exists():d=json.loads(p.read_text());result['assertions']={'passed':d['passed'],'failed':d['failed']}
 if label.startswith('portable-runtime'):
  p=directory/'negative/results.json'
  if p.exists():result['isolated_negative']=json.loads(p.read_text())
 if label=='smoke-isolated':
  p=directory/'results.json'
  if p.exists():result['isolated_negative']=json.loads(p.read_text())
  else:result['strict_status']='FAIL'
 report.append(result)
(out/'audit.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
for r in report:print(r['label'],r['strict_status'],'exit',r['exit'],'diagnostics',len(r['diagnostics']))
