from stage_utils import *
from Xlib import X,display,XK,protocol
from Xlib.ext import xtest
s=display.Display(':91')
def windows(pid):
 answer=[]
 for w in s.screen().root.query_tree().children:
  try:
   prop=w.get_full_property(s.intern_atom('_NET_WM_PID'),X.AnyPropertyType)
   if prop and int(prop.value[0])==pid and w.get_attributes().map_state==X.IsViewable:answer.append(w)
  except Exception:pass
 return sorted(answer,key=lambda w:w.get_geometry().width*w.get_geometry().height,reverse=True)
def key(w,name,pid):
 for unused in range(100):
  candidates=windows(pid)
  if candidates:break
  time.sleep(.1)
 else:raise RuntimeError('No mapped editor window for input')
 w=candidates[0];errors=[]
 w.configure(stack_mode=X.Above);w.set_input_focus(X.RevertToParent,X.CurrentTime,onerror=lambda error,request:errors.append(str(error)));s.sync()
 if errors:raise RuntimeError('XTEST focus failed: '+str(errors))
 code=s.keysym_to_keycode(XK.string_to_keysym(name));xtest.fake_input(s,X.KeyPress,code);s.sync();time.sleep(.1);xtest.fake_input(s,X.KeyRelease,code);s.sync()
 return w
def child_info(pid):
 return [{'pid':p,'command':v['cmd']} for p,v in process_table().items() if '--editor-pid '+str(pid) in v['cmd']]
def f5(label,project,cycles=3,full_wait=True):
 directory=out/label;directory.mkdir();shutil.copy2(project/'project.godot',directory/'project-settings.txt')
 cmd=['nice','-n','10','taskset','-c',','.join(map(str,cpus)),godot,'--editor','--path',str(project),'--rendering-method','gl_compatibility','--audio-driver','Dummy','--resolution','1600x1000']
 env=os.environ.copy();env.update(DISPLAY=':91',DOTNET_CLI_DO_NOT_USE_MSBUILD_SERVER='1',MSBUILDDISABLENODEREUSE='1',UseSharedCompilation='false')
 start=time.monotonic();records=[];error='';forced=False;tracked={}
 print('START',label,flush=True)
 with (out/(label+'-driver.log')).open('w') as log:
  p=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:
   w=None
   for unused in range(100):
    if p.poll() is not None:raise RuntimeError('editor exited during startup')
    candidates=windows(p.pid)
    if candidates:w=candidates[0];break
    time.sleep(.2)
   if w is None:raise RuntimeError('editor window unavailable')
   time.sleep(6)
   for cycle in range(cycles):
    w=key(w,'F5',p.pid);began=time.monotonic();data={'cycle':cycle,'captures':[]}
    for moment in ([2,15,60] if cycle==0 and full_wait else [2,15] if cycle==0 else [2]):
     time.sleep(max(0,began+moment-time.monotonic()))
     children=child_info(p.pid)
     for c in children:
      stat=process_table().get(c['pid'])
      if stat:tracked[c['pid']]=stat['start']
     filename=f'cycle-{cycle}-{moment}s.png';subprocess.run(['import','-display',':91','-window','root',str(directory/filename)],check=True,timeout=15)
     data['captures'].append({'seconds':round(time.monotonic()-began,2),'file':filename,'children':children})
    if cycle==1:
     w.configure(width=1400,height=900);s.sync();time.sleep(.5)
     subprocess.run(['import','-display',':91','-window','root',str(directory/'resized.png')],check=True,timeout=15)
    w=key(w,'F8',p.pid);time.sleep(2);data['children_after_f8']=child_info(p.pid);records.append(data)
   w.send_event(protocol.event.ClientMessage(window=w,client_type=s.intern_atom('WM_PROTOCOLS'),data=(32,[s.intern_atom('WM_DELETE_WINDOW'),X.CurrentTime,0,0,0])),event_mask=0);s.sync()
   p.wait(timeout=20)
  except Exception as e:
   error=str(e);forced=True
   if p.poll() is None:p.terminate()
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:p.kill();p.wait()
  finally:
   for pid,stamp in tracked.items():
    state=process_table().get(pid)
    if state and state['start']==stamp and state['state']!='Z':
     try:os.kill(pid,signal.SIGTERM)
     except ProcessLookupError:pass
 row={'label':label,'command':cmd,'env_overrides':{'DISPLAY':':91'},'source_commit':frozen['commit'],'exit':p.returncode,'seconds':round(time.monotonic()-start,2),'forced_stop':forced,'automation_error':error,'cycles':records,'child_exit_codes':'not directly observable; F8 disappearance and combined logs retained'}
 rows.append(row);(out/'commands.json').write_text(json.dumps(rows,indent=2));print('DONE',label,p.returncode,error,flush=True)
f5('f5-plain-dummy-final',out/'plain-f5',2,False)
