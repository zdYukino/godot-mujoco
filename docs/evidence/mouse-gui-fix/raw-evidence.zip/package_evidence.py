from pathlib import Path
import os,json,zipfile,hashlib,shutil
p=Path('/workspace/shared/validation/mouse-fix');full=p/'full';r=Path('/workspace/godot-mujoco');e=r/'docs/evidence/mouse-gui-fix';e.mkdir(parents=True,exist_ok=True)
a=json.loads((full/'audit.json').read_text());(e/'summary.json').write_text(json.dumps([{k:v for k,v in x.items() if k!='markers'} for x in a],indent=2,ensure_ascii=False)+'\n')
for n in ['commands.json','frozen.json','integrity.json','test-cleanup-delta.json'] :shutil.copy2(full/n,e/n)
shutil.copy2(p/'preflight-checks.json',e/'preflight-checks.json')
files=[]
for base,dirs,names in os.walk(p):
 dirs[:]=[n for n in dirs if n not in ['project','godot','relocated','plain-f5','plain-standalone','upload','__pycache__']]
 for name in names:
  f=Path(base)/name
  if f.suffix=='.png' and not any(str(f.relative_to(p)).startswith(x) for x in ['before/02-1-arm.png','full/mouse-gui-final/','full/g1-gui-final/gui/','full/f5-plain-dummy-final/','full/f5-mujoco-dummy-final/','full/editor-gui-0/screenshots/','restart-inspect/restart-restored.png','full/f5-mujoco-dummy/cycle-0-15s.png','full/f5-plain-dummy/cycle-0-15s.png']):continue
  if f.suffix in ['.log','.json','.jsonl','.py','.gd','.png','.txt'] or f.name.startswith('memory.'):files.append(f)
with zipfile.ZipFile(e/'raw-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in files:
  if f.name.startswith('processes-') and f.suffix=='.json':
   data=json.loads(f.read_text())
   for row in data.values():
    if not row['cmd'].startswith(('/workspace/shared/tools/Godot','/usr/lib/xorg/Xorg','/workspace/shared/tools/dotnet')):row['cmd']='[unrelated process command omitted]'
   z.writestr(str(f.relative_to(p)),json.dumps(data,indent=2))
  else:z.write(f,str(f.relative_to(p)))
selected={'before/02-1-arm.png':'tree-before.png','full/mouse-gui-final/02-2-arm.png':'tree-after.png','full/mouse-gui-final/08-viewport-shapes.png':'viewport-shapes.png','full/g1-gui-final/gui/05-rebuild-failed.png':'g1-rebuild-failed.png','full/g1-gui-final/gui/07-contact-low.png':'g1-low-friction.png','full/g1-gui-final/gui/07-contact-high.png':'g1-high-friction.png','full/g1-gui-final/gui/07-contact-barrier.png':'g1-barrier.png','full/f5-mujoco-dummy-final/cycle-0-60s.png':'f5-mujoco.png'}
for src,dst in selected.items():shutil.copy2(p/src,e/dst)
(e/'manifest.json').write_text(json.dumps([{'path':f.name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(e.iterdir()) if f.is_file() and f.name!='manifest.json'],indent=2)+'\n')
print('raw files',len(files),'zip bytes',(e/'raw-evidence.zip').stat().st_size)
