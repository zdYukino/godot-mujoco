import os,sys,time,json,pathlib,subprocess
from Xlib import X,display,XK
from Xlib.ext import xtest
s=display.Display(':91');folder=pathlib.Path(sys.argv[1]);checks=[]
def state():return json.loads((folder/'state.json').read_text())
def request(**kwargs):
 (folder/'request.tmp').write_text(json.dumps(kwargs));(folder/'request.tmp').replace(folder/'request.json');time.sleep(.4)
def key(name,ctrl=False,shift=False):
 mods=(['Control_L'] if ctrl else [])+(['Shift_L'] if shift else [])
 for k in mods:xtest.fake_input(s,X.KeyPress,s.keysym_to_keycode(XK.string_to_keysym(k)))
 c=s.keysym_to_keycode(XK.string_to_keysym(name));xtest.fake_input(s,X.KeyPress,c);xtest.fake_input(s,X.KeyRelease,c)
 for k in reversed(mods):xtest.fake_input(s,X.KeyRelease,s.keysym_to_keycode(XK.string_to_keysym(k)))
 s.sync();time.sleep(.06)
def move(x,y):xtest.fake_input(s,X.MotionNotify,x=int(x),y=int(y));s.sync()
def click(rect):
 x,y,w,h=rect;move(x+min(w/2,120),y+h/2);xtest.fake_input(s,X.ButtonPress,1);s.sync();time.sleep(.08);xtest.fake_input(s,X.ButtonRelease,1);s.sync();time.sleep(.4)
def item(name,kind=None):return next(i for i in state()['items'] if (i['name']==name or name=='sphere' and i['name'].startswith('sphere_')) and (not kind or i['kind']==kind))
def field(name,text):
 request(scroll=name);click(state()['fields'][name]['rect']);key('a',ctrl=True)
 for c in text:key(c if c not in {'.','-','[',']',','} else {'.':'period','-':'minus','[':'bracketleft',']':'bracketright',',':'comma'}[c])
 time.sleep(.4)
def button(name):
 matches=[c for c in state()['controls'] if c.get('text')==name]
 if not matches or matches[0]['rect'][1]>900:
  request(scroll=name);matches=[c for c in state()['controls'] if c.get('text')==name]
 click(matches[0]['rect'])
def shot(name):
 move(1550,980);time.sleep(.25);subprocess.run(['import','-display',':91','-window','root',str(folder/(name+'.png'))],check=True)
 (folder/(name+'.json')).write_text(json.dumps(state(),indent=2))
def check(v,label):
 checks.append({'name':label,'passed':bool(v)});print('PASS' if v else 'FAIL',label,flush=True)
def locked(draft):
 st=state();return st['selected'].get('name')=='hinge' and st['pending'] and st['fields']['damping']['text']=='0.2' and st['fields']['damping']['id']==draft and [i['name'] for i in st['items'] if i['selected']]==['hinge']
if __name__=='__main__':
 for _ in range(100):
  if (folder/'state.json').exists():break
  time.sleep(.2)
 click(item('hinge')['rect']);field('damping','0.2');draft=state()['fields']['damping']['id'];shot('01-draft')
 for name in ['arm','sphere','arm','sphere','arm']:
  click(item(name,'body')['rect']);move(1550,980);time.sleep(.3);check(locked(draft),'pending actual click '+name);shot('02-'+str(len(checks))+'-'+name)
 (folder/'mouse-results.json').write_text(json.dumps(checks,indent=2));request(quit=True)
