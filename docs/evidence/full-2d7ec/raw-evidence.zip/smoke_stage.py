from stage_utils import *
rc=run('smoke-isolated',['bash','tests/mjworld_smoke/run.sh'],240,{'OUT':str(out/'smoke-isolated')})
rows[-1]['source_commit']='2d7ec745 + test-only qpos isolation (commit recorded in report)'
(out/'commands.json').write_text(json.dumps(rows,indent=2))
raise SystemExit(rc)
