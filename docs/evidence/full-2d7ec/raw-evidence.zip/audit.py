import pathlib,json,re
out=pathlib.Path('/workspace/shared/validation/full-2d7ec');commands=json.loads((out/'commands.json').read_text());report=[]
for row in commands:
 label=row['label'];files=[out/(label+'-driver.log')]
 directory=out/label
 if directory.exists():files += [f for f in directory.glob('*.log') if not (label=='smoke-isolated' and f.name=='negative.log')]
 diagnostics=[];markers=[]
 for f in files:
  text=f.read_text(errors='replace')
  diagnostics += [{'file':str(f.relative_to(out)),'line':i,'text':line} for i,line in enumerate(text.splitlines(),1) if 'ERROR:' in line or 'leaked' in line]
  for line in text.splitlines():
   if re.search(r'(RESULT|TEST:|PASS|Ran \d+ tests)',line):
    if len(line)<500:markers.append({'file':str(f.relative_to(out)),'text':line})
    elif 'RESULT ' in line:
     try:
      d=json.loads(line.split('RESULT ',1)[1]);markers.append({'file':str(f.relative_to(out)),'summary':{k:v for k,v in d.items() if k not in ['checks','failures'] or not isinstance(v,list)}})
     except ValueError:pass
 result={'label':label,'source_commit':row['source_commit'],'exit':row['exit'],'seconds':row['seconds'],'strict_status':'PASS' if row['exit']==0 and not diagnostics else 'FAIL','diagnostics':diagnostics,'markers':markers}
 if label.startswith('editor-gui-') and not label.endswith('-import'):
  p=out/label/'results.json'
  if p.exists():d=json.loads(p.read_text());result['assertions']={'passed':d['passed'],'failed':d['failed']}
 if label.startswith('portable-runtime'):
  p=directory/'negative/results.json'
  if p.exists():result['isolated_negative']=json.loads(p.read_text())
 if label=='smoke-isolated':
  p=directory/'results.json'
  if p.exists():result['isolated_negative']=json.loads(p.read_text())
  else:result['strict_status']='FAIL'
 report.append(result)
(out/'audit.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
for r in report:print(r['label'],r['strict_status'],'exit',r['exit'],'diagnostics',len(r['diagnostics']))
