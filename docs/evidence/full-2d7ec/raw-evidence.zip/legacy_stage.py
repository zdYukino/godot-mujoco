from stage_utils import *
p=out/'g1/godot'
if not (p/'project.godot').exists():
 raise SystemExit('G1 staged demo unavailable; do not silently reuse historical fixture')
for label,scene in [('legacy-smoke','HeadlessTest.tscn'),('legacy-chaos','ChaosPendulumTest.tscn'),('legacy-debug-data','VisualDebugTest.tscn')]:
 run(label,[godot,'--headless','--path',str(p),'res://'+scene],120)
