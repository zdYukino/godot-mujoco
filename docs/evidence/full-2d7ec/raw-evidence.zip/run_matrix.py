import os,sys,pathlib,subprocess,json,time,signal,hashlib,shutil
root=pathlib.Path('/workspace/godot-mujoco');out=pathlib.Path('/workspace/shared/validation/full-2d7ec');godot=os.environ['GODOT_BIN'];rows=[]
cpus=sorted(os.sched_getaffinity(0))[:2]
def process_table():
 result={}
 for path in pathlib.Path('/proc').glob('[0-9]*'):
  try:
   text=(path/'stat').read_text();fields=text[text.rfind(')')+2:].split();result[int(path.name)]={'ppid':int(fields[1]),'start':fields[19],'state':fields[0],'cmd':(path/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')}
  except (OSError,ValueError):pass
 return result
baseline=process_table();(out/'processes-before.json').write_text(json.dumps(baseline,indent=2))
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=root).split(b'\0');manifest={p.decode():hashlib.sha256((root/p.decode()).read_bytes()).hexdigest() for p in tracked if p}
frozen={'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),'tracked_sha256':manifest,'engine_sha256':hashlib.sha256(pathlib.Path(godot).read_bytes()).hexdigest(),'cpus':cpus,'godot_version':subprocess.check_output([godot,'--version'],text=True).strip()}
(out/'frozen.json').write_text(json.dumps(frozen,indent=2))
for name in ['memory.max','memory.current','memory.events']:
 (out/(name+'-before')).write_text(pathlib.Path('/sys/fs/cgroup',name).read_text())
def run(label,cmd,limit=600,env=None):
 full=['timeout','--kill-after=5',str(limit),'nice','-n','10','taskset','-c',','.join(map(str,cpus))]+cmd
 own={};start=time.monotonic();e=os.environ.copy();e.update(env or {});e.update(DOTNET_CLI_DO_NOT_USE_MSBUILD_SERVER='1',MSBUILDDISABLENODEREUSE='1',UseSharedCompilation='false')
 print('START',label,flush=True)
 with (out/(label+'-driver.log')).open('w') as log:
  p=subprocess.Popen(full,cwd=root,env=e,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  while p.poll() is None:
   table=process_table();parents={p.pid}|set(own)
   for unused in range(6):
    for pid,v in table.items():
     if v['ppid'] in parents and pid not in baseline:own[pid]=v['start'];parents.add(pid)
   time.sleep(.4)
  rc=p.wait()
 cleaned=[];table=process_table()
 for pid,stamp in own.items():
  if pid in table and table[pid]['start']==stamp and table[pid]['state']!='Z':
   try:os.kill(pid,signal.SIGTERM);cleaned.append(pid)
   except ProcessLookupError:pass
 time.sleep(.3)
 table=process_table();survivors=[pid for pid in cleaned if pid in table and table[pid]['start']==own[pid] and table[pid]['state']!='Z']
 for pid in survivors:
  try:os.kill(pid,signal.SIGKILL)
  except ProcessLookupError:pass
 row={'label':label,'command':full,'env_overrides':env or {},'exit':rc,'seconds':round(time.monotonic()-start,2),'source_commit':frozen['commit'],'terminated_owned_children':cleaned,'killed_after_term':survivors};rows.append(row);(out/'commands.json').write_text(json.dumps(rows,indent=2));print('DONE',label,rc,row['seconds'],flush=True);return rc
run('build',['cmake','--build','/workspace/shared/builds/godot-mujoco-3.16','--clean-first','-j2'],1200)
frozen['extension_sha256']=hashlib.sha256((root/'demo/addons/godot_mujoco/bin/libgodot_mujoco.linux.template_debug.x86_64.so').read_bytes()).hexdigest();(out/'frozen.json').write_text(json.dumps(frozen,indent=2))
for label,script in [('native','tests/native_backend/run.sh'),('dynamic','tests/dynamic_scene/run.sh'),('g1','tests/g1_actuation/run.sh'),('editor','tests/editor_plugin/run.sh'),('freebase','tests/freebase/run.sh'),('clock','tests/runtime_clock/run.sh'),('live','tests/portable_runtime/run_live.sh')]:
 run(label,['bash',script],900,{'OUT':str(out/label),'MUJOCO_ROOT':'/workspace/shared/builds/godot-mujoco-3.16/_deps/mujoco-src','GODOT':godot})
run('negative-audit',['python3','-m','unittest','discover','-s','tests/portable_runtime','-p','test_world_rejection_audit.py'],60)
for i in range(3):
 for kind in ['assets','runtime']:
  label=f'portable-{kind}-{i}';rc=run(label,['bash',f'tests/portable_runtime/run_{kind}.sh'],900,{'OUT':str(out/label)})
  if kind=='runtime' and rc==0:
   project=out/label/'relocated';shutil.copy2(root/'tests/stability/runtime_pressure.gd',project/'runtime_pressure.gd')
   run('pressure-'+str(i),[godot,'--headless','--path',str(project),'--script','res://runtime_pressure.gd'],300)
   run('pressure-audit-'+str(i),['python3','tests/stability/log_checks.py',str(out/('pressure-'+str(i)+'-driver.log'))],30)
for i in range(5):
 d=out/f'editor-gui-{i}';project=d/'project';shutil.copytree(root/'tests/editor_plugin',project);shutil.copytree(root/'demo/addons',project/'addons')
 if run(f'editor-gui-{i}-import',['bash','scripts/import_headless.sh',str(project)],120)!=0:continue
 run(f'editor-gui-{i}',[godot,'--editor','--path',str(project),'--rendering-method','gl_compatibility','--audio-driver','Dummy','--resolution','1600x1000','--','--mj-editor-test','--report='+str(d/'results.json'),'--capture-dir='+str(d/'screenshots')],180,{'DISPLAY':':91'})
for name in ['memory.max','memory.current','memory.events']:(out/(name+'-after')).write_text(pathlib.Path('/sys/fs/cgroup',name).read_text())
(out/'processes-after.json').write_text(json.dumps(process_table(),indent=2))
print('MATRIX FINISHED',flush=True)
