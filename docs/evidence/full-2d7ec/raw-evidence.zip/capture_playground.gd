extends SceneTree
var app: Node
var controls: Node
var folder: String
func ticks(n: int) -> void:
 for unused in n:
  await physics_frame
  await process_frame
func button(prefix: String) -> void:
 for child in controls.get_children():
  if child is Button and child.text.begins_with(prefix):child.pressed.emit();return
 assert(false,"button missing")
func shot(name: String) -> void:
 await RenderingServer.frame_post_draw
 assert(root.get_texture().get_image().save_png(folder.path_join(name))==OK)
func _initialize() -> void:call_deferred("run")
func run() -> void:
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--capture-dir="):folder=arg.trim_prefix("--capture-dir=")
 DirAccess.make_dir_recursive_absolute(folder)
 app=load("res://FreebasePlayground.tscn").instantiate();root.add_child(app);await ticks(6)
 controls=app.get_node("SimulationControls")
 var host=app.get_node("EnvironmentHost")
 await shot("01-paused.png")
 controls.count.get_line_edit().text="10";button("单步");await ticks(4)
 assert(abs(host.world.info().time-.02)<1e-10);await shot("02-step10.png")
 button("恢复");await ticks(120);button("暂停");await ticks(4);await shot("03-fallen.png")
 button("重置仿真");await ticks(4);assert(host.world.info().time==0);await shot("04-reset.png")
 var previous=host.world;var saved=host.environment_scene
 var invalid:=PackedScene.new();var empty:=Node.new();invalid.pack(empty);empty.free();host.environment_scene=invalid
 button("重建已保存");await ticks(4)
 assert(host.world==previous and controls.status.text.contains("Environment rebuild failed"));await shot("05-rebuild-failed.png")
 host.environment_scene=saved;button("重建已保存");await ticks(5)
 assert(controls.status.text.contains("Environment rebuild succeeded"));await shot("06-rebuild-success.png")
 app.queue_free();await ticks(3);print("PLAYGROUND_GUI_PASS: pause, exact10, fall, reset, visible failed rebuild, retry success");quit(0)
