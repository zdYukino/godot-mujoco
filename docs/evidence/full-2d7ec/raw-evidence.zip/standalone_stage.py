from stage_utils import *
plain=out/'plain-standalone';shutil.copytree(root/'tests/embedded_display/plain',plain)
(plain/'capture_plain.gd').write_text('''extends SceneTree
func _initialize() -> void: call_deferred("run")
func run() -> void:
 var scene=load("res://Main.tscn").instantiate();root.add_child(scene)
 for unused in 120: await physics_frame
 await RenderingServer.frame_post_draw
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--capture="): assert(root.get_texture().get_image().save_png(arg.trim_prefix("--capture="))==OK)
 scene.queue_free();await process_frame;print("PLAIN_WINDOW_PASS");quit(0)
''')
run('plain-standalone-import',['bash','scripts/import_headless.sh',str(plain)],120)
run('plain-standalone',[godot,'--path',str(plain),'--rendering-method','gl_compatibility','--audio-driver','Dummy','--script','res://capture_plain.gd','--','--capture='+str(out/'plain-standalone.png')],90,{'DISPLAY':':91'})
project=out/'portable-runtime-0/relocated'
if (project/'project.godot').exists():run('fixed-standalone',[godot,'--path',str(project),'--rendering-method','gl_compatibility','--audio-driver','Dummy','--script','res://capture_runtime.gd','--','--capture='+str(out/'fixed-standalone.png')],120,{'DISPLAY':':91'})
project=out/'freebase/project'
if (project/'project.godot').exists():
 shutil.copy2(root/'tests/freebase/prepare_playground.gd',project/'prepare_playground.gd');shutil.copy2(out/'capture_playground.gd',project/'capture_playground.gd')
 if run('freebase-prepare',[godot,'--headless','--path',str(project),'--script','res://prepare_playground.gd'],120)==0:
  run('freebase-standalone',[godot,'--path',str(project),'--rendering-method','gl_compatibility','--audio-driver','Dummy','--resolution','1500x950','--script','res://capture_playground.gd','--','--capture-dir='+str(out/'freebase-gui-images')],120,{'DISPLAY':':91'})
